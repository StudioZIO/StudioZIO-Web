# StudioZIO MixRack 1.0.0 — press kit

StudioZIO MixRack is a modular mixing environment for macOS: eight processing
modules in one rack, on a single signal path, in the order you arrange them.

This kit holds the material StudioZIO has cleared for editorial use. Everything
in it is checked against the release that shipped. Nothing is embargoed.

## What is in the kit

    README.md              This file: the release, the modules, what installs,
                           what has been validated, and what not to write.
    PRESS-COPY.md          Ready-to-use descriptions at 50, 100 and 150 words,
                           plus the one-line boilerplate.
    TECHNICAL-SPECS.md     Formats, architectures, requirements, latency,
                           installed paths and checksums.
    screenshots/           Four unretouched captures of the shipping 1.0.0
                           interface. See screenshots/CREDITS.txt.
    branding/              The StudioZIO mark and the MixRack share card. See
                           branding/NOTICE.txt.

## The release

| | |
| --- | --- |
| Product | StudioZIO MixRack |
| Version | 1.0.0 |
| Release date | 29 September 2026 |
| Platform | macOS 11 or newer |
| Architecture | Universal — arm64 and x86_64, in all four formats |
| Formats | Audio Unit (AU), VST3, AAX, Standalone application |
| Bundle identifier | com.studiozio.ziomixrack |
| Installer | StudioZIO-Mixrack-1.0.0.pkg |
| Installer SHA-256 | 9452403bf1150bd4188cbfe550f1ad0840087c68fe0b56f5036f08e17b4a4fda |
| Developer | StudioZIO — Mert Erkan, Istanbul |

Product page: https://studioziomixrack.vercel.app/
Support: https://www.studiozio.tech/contact/

## The eight modules

In the order they appear in a new rack:

1. Gain
2. Three-Band EQ
3. Channel Mixer
4. Compressor
5. Gate
6. Transient Shaper
7. Clipper
8. Limiter

Any module can be moved. What you see top to bottom is what the audio passes
through, first to last.

## Installation

The installer is signed with a Developer ID Installer certificate, notarised by
Apple and stapled, and the package passes Gatekeeper assessment as a notarised
Developer ID package. It installs:

    /Applications/StudioZIO Mixrack.app
    /Library/Audio/Plug-Ins/Components/StudioZIO Mixrack.component
    /Library/Audio/Plug-Ins/VST3/StudioZIO Mixrack.vst3
    /Library/Application Support/Avid/Audio/Plug-Ins/StudioZIO Mixrack.aaxplugin

No account, no licence key, no iLok, no email registration.

## Validation

- Audio Unit: `auval` passes (component version 1.0.0).
- AU and VST3: `pluginval` passes at strictness level 10, against the installed
  builds rather than the build tree.
- AAX: signed with PACE wraptool. The signed AAX release was checked directly in
  Pro Tools for loading, insertion, UI, audio pass-through, parameter
  interaction, bypass, state recall and version reporting.
- Code signature: `codesign --verify --deep --strict` passes for all four
  formats.

## Where the claims stop

Please do not write any of the following, because StudioZIO has not established
them:

- that MixRack is certified by Avid, Apple or anyone else;
- that it works with every Pro Tools version — one version was checked, by hand,
  and that check is described above in the words it deserves;
- that it is faster, cleaner or better than any other product;
- that it runs on Windows or Linux — there is no build for either;
- a price, a promotion, or any endorsement.

If something here is not enough to write the sentence you want, ask rather than
infer: https://www.studiozio.tech/contact/

## A note on spelling

The product is written **StudioZIO MixRack** in prose. The installer, the bundle
identifier and the installed filenames use `Mixrack` with a lowercase r. That
difference is in the shipped artefacts and is reproduced here exactly, so
checksums and paths match what is on disk.
