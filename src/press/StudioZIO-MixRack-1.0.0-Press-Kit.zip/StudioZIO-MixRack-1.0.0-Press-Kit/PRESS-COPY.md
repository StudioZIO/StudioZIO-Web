# Ready-to-use descriptions

Three lengths of the same description. Use any of them as they are, or cut them
further. No approval is needed and no attribution line is required.

---

## 50 WORDS

StudioZIO MixRack is a modular mixing environment for macOS. Eight processing
modules — gain, EQ, channel mixing, compression, gating, transient shaping,
clipping and limiting — sit on one signal path in whatever order you arrange
them. It is free, and ships on 29 September 2026 in AU, VST3, AAX and
Standalone.

---

## 100 WORDS

StudioZIO MixRack is a modular mixing environment for macOS that brings eight
processing modules into a single rack. Gain, Three-Band EQ, Channel Mixer,
Compressor, Gate, Transient Shaper, Clipper and Limiter share one signal path,
and the order you arrange them in is the order the audio passes through. Each
slot reads its module, main value, gain reduction, mix and on/off in one line,
so the whole chain is visible at once. MixRack 1.0.0 arrives on 29 September
2026 for macOS 11 or newer, as a Universal build in AU, VST3, AAX and
Standalone. It is free permanently — no trial, no licence key, no account.

---

## 150 WORDS

StudioZIO MixRack is a modular mixing environment for macOS, built around one
idea: a mix chain should be legible. Eight processing modules — Gain, Three-Band
EQ, Channel Mixer, Compressor, Gate, Transient Shaper, Clipper and Limiter —
share a single signal path, and the order you arrange them in is the order the
audio passes through. Each slot states its module, main value, gain reduction,
mix and on/off in one line, so the whole chain can be read without opening
anything. Modules can be reordered by dragging, with their settings, bypass and
mix moving as one undo step. Output metering covers peak, true peak, RMS,
correlation and loudness, and two complete racks can be compared as A and B.
MixRack 1.0.0 is released free on 29 September 2026 for macOS 11 or newer: a
Universal build — Apple Silicon and Intel — in Audio Unit, VST3, AAX and
Standalone formats, from StudioZIO in Istanbul.
