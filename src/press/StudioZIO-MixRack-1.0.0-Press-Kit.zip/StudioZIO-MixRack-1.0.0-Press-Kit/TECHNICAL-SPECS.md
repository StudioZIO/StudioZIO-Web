# StudioZIO MixRack 1.0.0 — technical specifications

Every value here is read from the release that shipped.

## Product

| Field | Value |
| --- | --- |
| Product | StudioZIO MixRack |
| Version | 1.0.0 |
| Release date | 29 September 2026 |
| Developer | StudioZIO — Mert Erkan, Istanbul |
| Price | Free permanently |
| Platform | macOS |
| Minimum macOS | 11.0 |
| Architecture | Universal — arm64 and x86_64, in all four formats |
| Formats | Audio Unit (AU), VST3, AAX, Standalone application |
| Bundle identifier | com.studiozio.ziomixrack |
| Product page | https://studioziomixrack.vercel.app/ |
| Support | https://www.studiozio.tech/contact/ |

## Modules

Eight, in the order a new rack presents them: Gain, Three-Band EQ, Channel
Mixer, Compressor, Gate, Transient Shaper, Clipper, Limiter. Any of them can be
moved; the rack's order is the signal order.

The module browser groups them four ways:

| Group | Modules |
| --- | --- |
| Utility | Gain, Channel Mixer |
| Dynamics | Compressor, Gate, Transient Shaper, Limiter |
| EQ | Three-Band EQ |
| Saturation | Clipper |

A rack holds eight slots. All eight modules can be loaded at once, one per slot.

## Installer

| Field | Value |
| --- | --- |
| Filename | StudioZIO-Mixrack-1.0.0.pkg |
| SHA-256 | 9452403bf1150bd4188cbfe550f1ad0840087c68fe0b56f5036f08e17b4a4fda |
| Signed | Yes — Developer ID Installer, trusted timestamp |
| Notarised | Yes — accepted by Apple, no issues raised |
| Stapled | Yes — `stapler validate` passes |
| Gatekeeper | Accepted, source reported as Notarized Developer ID |

The SHA-256 above is of the notarised and stapled package — the file that is
published. Stapling changes the bytes, so a checksum taken before it will not
match; this is the one to quote.

## Installed paths

    /Applications/StudioZIO Mixrack.app
    /Library/Audio/Plug-Ins/Components/StudioZIO Mixrack.component
    /Library/Audio/Plug-Ins/VST3/StudioZIO Mixrack.vst3
    /Library/Application Support/Avid/Audio/Plug-Ins/StudioZIO Mixrack.aaxplugin

## Code signing

Signed with Developer ID Application (StudioZIO — Mert Erkan, team 3734G7VLNA).
`codesign --verify --deep --strict` passes for the Audio Unit, VST3, AAX and
Standalone builds. The AAX build is signed with PACE wraptool.

## Validation

| Check | Result |
| --- | --- |
| `auval` (Audio Unit) | Passes; component version reported as 1.0.0 |
| `pluginval` — AU | Passes at strictness level 10, installed build |
| `pluginval` — VST3 | Passes at strictness level 10, installed build |
| Payload hygiene | No AppleDouble records, no extended attributes |

## Host checking

The signed AAX release was checked directly in Pro Tools for loading,
insertion, UI, audio pass-through, parameter interaction, bypass, state recall
and version reporting.

That sentence is the whole claim. MixRack is not certified by Avid, and no
statement is made about Pro Tools versions other than the one checked, or about
any other host. AU and VST3 rest on the `auval` and `pluginval` results above,
which are format validation rather than host compatibility.

## Price

Free permanently. Not a trial, not time-limited, not feature-locked, and not a
reduced version of a paid tier — there is no paid tier. No licence key, no iLok
requirement and no registration of any kind.

## Not applicable

There is no Windows build and no Linux build.
